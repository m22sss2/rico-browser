using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

internal static class RicoWindowBrand
{
    private const uint GetIcon = 0x007f;
    private const uint SetIcon = 0x0080;
    private static readonly Guid AppModel = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
    private delegate bool WindowCallback(IntPtr window, IntPtr data);

    [DllImport("user32")]
    private static extern bool EnumWindows(WindowCallback callback, IntPtr data);
    [DllImport("user32")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32")]
    private static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32")]
    private static extern int GetSystemMetrics(int metric);
    [DllImport("user32", CharSet = CharSet.Unicode)]
    private static extern IntPtr LoadImage(IntPtr instance, string name, uint type, int width, int height, uint flags);
    [DllImport("user32")]
    private static extern bool DestroyIcon(IntPtr icon);
    [DllImport("user32", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr window, System.Text.StringBuilder name, int capacity);
    [DllImport("user32", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessageTimeout(IntPtr window, uint message, IntPtr wParam, IntPtr lParam,
        uint flags, uint timeout, out IntPtr result);
    [DllImport("shell32")]
    private static extern int SHGetPropertyStoreForWindow(IntPtr window, ref Guid type, out IPropertyStore store);

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    private struct PropertyKey
    {
        public Guid format;
        public uint id;
    }

    [StructLayout(LayoutKind.Explicit, Size = 24)]
    private struct PropertyValue
    {
        [FieldOffset(0)] public ushort type;
        [FieldOffset(8)] public IntPtr pointer;
    }

    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IPropertyStore
    {
        uint GetCount();
        void GetAt(uint index, out PropertyKey key);
        void GetValue(ref PropertyKey key, out PropertyValue value);
        void SetValue(ref PropertyKey key, ref PropertyValue value);
        void Commit();
    }

    internal static void Follow(Process browser, string root)
    {
        string iconPath = Path.Combine(root, "assets", "rico.ico");
        IntPtr small = LoadImage(IntPtr.Zero, iconPath, 1, GetSystemMetrics(49), GetSystemMetrics(50), 0x10);
        IntPtr large = LoadImage(IntPtr.Zero, iconPath, 1, GetSystemMetrics(11), GetSystemMetrics(12), 0x10);
        var brandedWindows = new HashSet<IntPtr>();
        try
        {
            uint browserId = (uint)browser.Id;
            while (!browser.HasExited)
            {
                var currentWindows = new HashSet<IntPtr>();
                EnumWindows((window, data) =>
                {
                    uint owner;
                    GetWindowThreadProcessId(window, out owner);
                    if (owner != browserId || !IsWindowVisible(window)) return true;
                    var name = new System.Text.StringBuilder(64);
                    GetClassName(window, name, name.Capacity);
                    if (name.ToString() != "MozillaWindowClass") return true;
                    currentWindows.Add(window);
                    ApplyIcon(window, 0, small);
                    ApplyIcon(window, 1, large);
                    if (!brandedWindows.Contains(window))
                        ApplyTaskbar(window, root, iconPath);
                    return true;
                }, IntPtr.Zero);
                brandedWindows = currentWindows;
                browser.WaitForExit(500);
            }
        }
        finally
        {
            if (small != IntPtr.Zero) DestroyIcon(small);
            if (large != IntPtr.Zero) DestroyIcon(large);
        }
    }

    private static void ApplyIcon(IntPtr window, int size, IntPtr icon)
    {
        if (icon == IntPtr.Zero) return;
        IntPtr current;
        if (SendMessageTimeout(window, GetIcon, (IntPtr)size, IntPtr.Zero, 2, 100, out current) != IntPtr.Zero &&
            current != icon)
            SendMessageTimeout(window, SetIcon, (IntPtr)size, icon, 2, 100, out current);
    }

    private static void ApplyTaskbar(IntPtr window, string root, string icon)
    {
        Guid type = typeof(IPropertyStore).GUID;
        IPropertyStore store;
        if (SHGetPropertyStoreForWindow(window, ref type, out store) != 0) return;
        try
        {
            Put(store, 2, "\"" + Path.Combine(root, "rico.exe") + "\"");
            Put(store, 3, icon + ",0");
            Put(store, 4, "Rico Browser");
            Put(store, 5, "RicoBrowser.Desktop");
            store.Commit();
        }
        catch (COMException) { }
        finally { Marshal.ReleaseComObject(store); }
    }

    private static void Put(IPropertyStore store, uint id, string text)
    {
        var key = new PropertyKey { format = AppModel, id = id };
        var value = new PropertyValue { type = 31, pointer = Marshal.StringToCoTaskMemUni(text) };
        try { store.SetValue(ref key, ref value); }
        finally { Marshal.FreeCoTaskMem(value.pointer); }
    }
}
